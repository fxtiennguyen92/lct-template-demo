<ul class="navigation clearfix">
	<li><a href="{{ route('home') }}">Accueil</a></li>
	<li><a href="{{ route('menu') }}">Menu</a></li>
	
	<li><a href="#footer">Contacter</a></li>
</ul>